Tss_dewpoint <-function(Ta, regn)
{
#Fra Raleigh et al. Wrr 2013
# Using estimated Dew point temperaure as proxy for Tss  
#  Author Thomas Skaugen
#  Last revised : 7.03 2018
  
  
Wa <- CloudCover(Ta,regn)$Wa #Ta er ikke riktig, men brukes ikke i CloudCover enn�  
if (Ta  > 0.0)
{
   b=17.625
   c=243.04 # Celscius
}

if (Ta  <= 0.0)
{
  b=22.587
  c=273.86
}  

Td <- c*(log(Wa) +(b*Ta)/(c+Ta))/(b-log(Wa)-(b*Ta)/(c+Ta))

resultTss <-NULL
resultTss$Tss <-Td
resultTss
}