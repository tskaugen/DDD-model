#    Function OverlandFlowDynamicDD
#
#------------------------------------------------------------------------
#     Description:  Estimates a dynamic distance distribution for overland flow. 
#                   ddist is a vector of weights, distributing outx to the layers
#     Author: Thomas Skaugen
#     Revised: 01.02.2018
#--------------------------------------------------------------------------


OverlandFlowDynamicDD <-function(k,ddist,outx, layerUH, nodaysvector,NoL, midDL, CritFlux, Timeresinsec)
{
  A2 <- CritFlux/(outx*ddist[1]/1000)     #Area in m2 that generates critical volume
  #dmean <- A2^0.25# (A2^0.5)^0.5          # doesn't work
  #dmean <- ((A2+A2)^0.5)/2                # half of the diagonal Works better
  #dmean =(A2/(pi*1.25))^0.5*(1.5/2)        # approx ovoid shaped catchment. Two circles, with one double the radius of the other.dmean  is the mean of the two diameters: Works pretty good
  dmean <- 0.5*A2^0.5  #30.4.2018 The mean describes half of the critical area, as it does for the entire catchment. Kind of logical
  if (dmean > midDL) dmean <- midDL       #degenerates to natural river network
  print(paste("Area is: ",round(A2,1), "dmean is:", round(dmean,1), "outx[mm]is: ", round(outx,1), "outx*ddist is: ",round(outx*ddist[1],1) ))
  maxdistOF <-  qexp(0.999, 1/dmean)      #such that 0.99 of the area contributes
  celerityOF <- k[1]                      #overland flow celerity
  zOF <- 0.05                             #areal fraction of river network; a fixed mean 
  OFUH <- SingleUH(celerityOF,Timeresinsec, dmean, maxdistOF, zOF)
  #browser()
  layerUH[1,1:length(OFUH)]<- OFUH[1:length(OFUH)]
  layerUH[1,((length(OFUH)+1):nodaysvector[NoL])] <- 0.0

  OverlandFlowDynamicDD <- NULL
  OverlandFlowDynamicDD$OFlayer <- layerUH[1,]
  OverlandFlowDynamicDD
  
}