#    Function Wetlands(isoilx,sncovx,smx,outx,ceax,tempx,lp,ep)
#
#C------------------------------------------------------------------------
#C
#      New moisture routine 
#C
#C     Beskrivelse:  Rutinen beregner markvannsmagasin. 
#
#     Author: Thomas Skaugen
#     Revised: 16.11.2017
#
#     Parametere:
#     EA       Actual evapotransp
#     cea      Evaporation constant[mm/deg/day]   
#     toSoil    Rain/snowmelt
#     middelsca    Snowcovered area
#     smbog       Soil moisture content, mm # note that smbog is the entire reservoir for bogs, so delta_smbog is dicharge to the RN
#     D       Saturation deficit (D>Z) mm
#     M       Total subsurface water reservoir mm
#     OUTBOG  Outflow form soil moisture reservoir mm/d
#--------------------------------------------------------------------------


Wetlands_EB <- function(misoil,eatemp,middelsca,smbog,M,ET)
{

#------------------------------------------------------------------------
# Initialisering av out
#----------------------------------------------------------------------- 
     
      outxbog <- 0.0

#-------------------------------------------------------------------------
#  Actual evapotranspiration
#-------------------------------------------------------------------------

       if (eatemp > -10.0)# Function of temp, areal  meanm, see S�lthun 1996, p. 9
            #cea is a kind of degree-day factor , cea*temp is potential evapotranspiration which becomes actual due to deficit
          {
       
             eabog<-min(ET, ET*((smbog+misoil)/M))
             #misoil <- max(0,misoil-eabog)
          }
       else
          {
             eabog <-0.0
          }
      
#------------------------------------------------------------------------
#     Updating sm caused by evapotranspiration
#------------------------------------------------------------------------
      smbog <- smbog-eabog
      
      if (smbog < 0) # prevents breaching the water balance, must adjust ea
      {
        eabog <- eabog + smbog #sm is negative
        smbog <- 0
      }
      
#------------------------------------------------------------------------
#     Updating smbog caused by evapotranspiration
#------------------------------------------------------------------------
      Bograt <- (smbog+misoil)
      if(Bograt > M)
      {
        outbog <-(Bograt-M)    #Excess water released to runoff
        smbog <-M
      }
      else
      {
        outbog <- 0
        smbog <- smbog+misoil
      } 
        
                                      


resultbog <-NULL
resultbog$outbog <-outbog
resultbog$smbog <-smbog
resultbog$eabog <-eabog
resultbog
}

     