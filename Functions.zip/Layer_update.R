#    Function Layer_update
#
#------------------------------------------------------------------------
#     Description:  Updates Layers by todays event and shifting to one timestepahead. 
#
#     Author: Thomas Skaugen
#     Revised: 17.11.2017
#--------------------------------------------------------------------------

Layer_update <-function (ddist,outx, Layers, layerUH, nodaysvector, NoL)
{
  for (j in 1: NoL)
  {
    qlayer <-ddist[j]*outx*layerUH[j,1:nodaysvector[j]]    #finds response  in mm!!!!  for the actual layer, en vektor     
    if(nodaysvector[j] >1)
    {
      Layers[j,(1:nodaysvector[j]-1)] <- Layers[j,2:nodaysvector[j]] + qlayer[2:nodaysvector[j]]# flytter the level of the matrix one timestep ahead
      Layers[j,nodaysvector[j]] <-0.0
      #Layers[j,1:(nodaysvector[j]-1)] <- Layers[j,1:(nodaysvector[j]-1)] + qlayer[2:nodaysvector[j]] # update with todays event minus this timesteps contribution. 
    } 
    #print(qlayer)
    if(nodaysvector[j] ==1)Layers[j,1:nodaysvector[j]] <- qlayer[1:nodaysvector[j]]
  }

LayerUpdate <- NULL
LayerUpdate$Layers <- Layers
LayerUpdate
  
}
