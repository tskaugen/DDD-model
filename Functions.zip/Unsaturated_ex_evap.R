#    Function Unsaturated_evap(isoilx,sncovx,smx,outx,ceax,tempx,lp,ep)
#
#C------------------------------------------------------------------------
#
#     Description: Calculates soil moisture (unsaturated) and evapotranspiration (Priestley-Taylor)
#     Author: Thomas Skaugen
#     Revised: 09.3.2018
#
#     Parameters:
#     EA       Actual evapotransp
#     CEA      Evaporation constant[mm/deg/day]   
#     MIDDELSCA    Snowcovered area
#     sm       Soil moisture content, mm
#     D       Saturation deficit (D>Z) mm
#     M       Total sudsurface water reservoir mm
#     OUTX      Outflow form soil moisture reservoir mm/d
#     Constant
#     R       A fraction volumetric Water content 30 %
#     
#--------------------------------------------------------------------------

Unsaturated_ex_evap <- function(toSoil,sm,M,D)
{

      R <- 0.3     
      outx <- 0.0

#--------------------------------------------------------------------------------------------------------
#     Estimating retention of moistureinput to sm and runoff
#     The theory is that saturated and unsaturated sone share the same volume, and are hence the complement
#     of each other 
#--------------------------------------------------------------------------------------------------------      
      
      ifelse(D > 0, rat <-(sm+toSoil)/D, rat <-1) #taking into account that D can be zero or even negative (overland flow), complete saturation.
      
      if(rat > R)
      {
        outx <-(sm+toSoil)-R*D
        sm <-R*D
      }
      else
      {
        outx <- 0
        sm <- sm+toSoil
      }        
        
resultmark <-NULL
resultmark$outx <-outx
resultmark$sm <-sm
resultmark
}

     