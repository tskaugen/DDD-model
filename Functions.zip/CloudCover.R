CloudCover <-function(Temp,regn)
{
len <- length(Temp)
wgt <- vector("numeric",len)
#Temperaturvektoer er slik at f�rste element er dagens temperatur
#ifelse(regn > 0, Cl <- 1.0, Cl <-0.1) #Cloudcover 100 % if precipitation, zero otherwise Litt brutal, ganske mange skyete dager
grense <- 0.7
pgrense <- 1.0
#Estimating Cloudcover 
if(regn > pgrense)Cl <- 1.0# 1 for 1 time funker bra, 3 for 3 timer?
if(regn > 0.0 && regn <=pgrense) Cl <- runif(1,grense,1.0)
if(regn==0) Cl<-runif(1,0.1,grense)# 

if(Cl >= grense)Wa <- (Cl+1.567)/2.667       # parametrization of Relative Humidity from Herrero and Polo(HESS, 2012) 

if(Cl < grense)Wa <- 0.8349                  # mean values from Filefjell

if(Cl < (grense-0.1))Wa <- (Cl+1.167)/2.667  # parametrization of Relative Humidity from Herrero and Polo(HESS, 2012)

if(Wa > 1.0)Wa<-1.0

#print(paste("Wa= ", round(Wa,3),"Cl=", round(Cl,3)))

resultCoudCover <-NULL
resultCoudCover$Cl <-Cl
resultCoudCover$Wa <- Wa
resultCoudCover
}