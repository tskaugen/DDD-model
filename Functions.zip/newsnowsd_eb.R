#Function newsnowsd
#denne funsksjonen beregner nysn� og sn�dyp
#Denne funksjonen har input:
#P               : nedb�r i mm
#T		     :temperatur erstattes med T
#TX              :skilletemp regn/sn�
#TS		     :skilletemp smelting/frysing
#CFR		     :Correksjonsfaktor for CX for refrysing
#swex            :yesterday reservoir of snow
#swe		     :todays updated reservoir of snow
#xmw             :dagens smelting

#og Output:
#MW              :potenial melt/refreeze(negative) mm
#PR		     :nedb�r som regn
#PS              : nedb�r som sn�

#Denne funksjonen
#KalleS : hovedprogram
#KalleR : newsnowdensity(T)


newsnowsd <-function(PRX,PSX,T,TX,xmw,swe,swex,snowdepth)

{

#source("F:\\HB\\HB-sn�\\Stefano\\senorge1D\\scripts\\newsnowdensity.R")
#source("F:\\HB\\HB-sn�\\Stefano\\senorge1D\\scripts\\densityage.R")

MaxDensity <-0.7
MaxChange <-0.9
#snowdepth is current snowdepth prior to updating


    if(T > TX){
		newsnow <- 0.0      
    }else{
		newsnow <- PSX
    }

#Change snowdepth due to snowmelt
#swex previous instant
#swe updated

	if(swex > 0 && swe > 0){
		density <- swex/snowdepth 
		if(xmw>0) snowdepth <- snowdepth - xmw/density
		if(snowdepth<0) snowdepth<-0.0
	}else{
		density <- 0.1
		snowdepth <- 0.0
	}
		
	density_new <- newsnowdensity(T)

	if(swe>0){
		if(snowdepth==0){
			delta_depth = 0
		}else{
			delta_depth <- 25.4*(newsnow/25.4)*(snowdepth/25.4)/((swe-newsnow)/25.4)* (snowdepth/25.4/10.0)^0.35
	
			#From Bras reduction in depth due to weigth of newsnow
			#print(paste('dD',delta_depth,'Max',MaxChange,'sD',snowdepth,'MaxDens',MaxDensity))

			#if(delta_depth > MaxChange*snowdepth) delta_depth <- MaxChange*snowdepth

			if(delta_depth > snowdepth-swe/MaxDensity) delta_depth <- snowdepth-swe/MaxDensity
		}
 
		# updatet snowdepth due to newsnow
		snowdepth <- snowdepth + (newsnow/density_new) - delta_depth
		#snowdepth <- snowdepth + (newsnow/density_new) 
	}
 
#snowdepth due to ageing HER SKAL ALDERS COMPACTION due to age be called 
snowd_new <- densityage(snowdepth,swe,T)
snowdepth <- snowd_new


#returnerer resultater
resultsd <-NULL
resultsd$sndepth<-snowdepth
resultsd$dens <-density
#resultsd$MW <-MW
#resultsd$MWGLAC <- MWGLAC 
resultsd
}