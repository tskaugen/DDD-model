#Denne subrutinen estiemrer albedo etter Todd Walter (2005) sitt paper i JOH

AlbedoWalter <-function(deltaSWE,SWE,Ta,Aprim,Timeresinsec,thrx)
{
#rm(list=ls())
#24 timers albedo
AX <-0.95 #maximum albedo
SWE <- SWE+deltaSWE
h_swe <-0.05# meter
A_bg <-0.25 #Generic albedo for snowless ground(Campell, 1977)
#Aprim <-0.86 #initial verdi
#Abedo decay
if((Timeresinsec ==86400) || (thrx==12))#Oppdatere albedoen
{
 if (deltaSWE <= 0.0)
 {
   A <-0.35-(0.35-AX)*exp(-(0.177+log((AX-0.35)/(Aprim-0.35))^2.16))^0.46 #US Army corps of engineers (empirical)
   Aprim <- A
   #print("her er jeg")
 }
#Albedo new snow
#snow density
#deltaSWe i meter
 if(deltaSWE > 0.0)
 {
   Srho <- 50 +3.4*(Ta+15) #kg/m3, density new snow
   A <- AX-(AX-Aprim)*exp(-((4*deltaSWE*Srho)/0.12))
   Aprim <- A
 }
}
else #vi bruker forrige tidsskritts albedo
{
 A <- Aprim
 #print("her er jeg2")
}

albedo_init <- A
R <-(1-(SWE/h_swe))*exp(-(SWE/(2*h_swe)))

ifelse(SWE < h_swe,albedo <- R*A_bg+(1-R)*albedo_init,albedo <- albedo_init) #interpolerer albedo til bare ground albedo

#print(paste("inne i AlbedoWalter, SWE=",SWE,"albedo=",albedo ))

resalbedo <- NULL
resalbedo$Aprim <- Aprim
resalbedo$albedo <- albedo
resalbedo
}
