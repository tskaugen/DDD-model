#    Function RainSnowSnowmelt
#
#------------------------------------------------------------------------
#     Description:  Calculates if precipitation is solid/liquid and melt from snow and glaciers 
#
#     Author: Thomas Skaugen
#     Revised: 17.11.2017
#--------------------------------------------------------------------------


RainSnowSnowmelt <- function(hson,hprecip,htemp,TS,TX,pkorr,skorr,CX,CGLAC,CFR) 
{
  # Sjekk ut gjenfrysingen!!!!!!!!!!!        
  for(idim in 1:hson)#elevation zones
  {
    
    if(htemp[idim] > TX)
    {
      PR[idim] <-hprecip[idim]*pkorr
      PS[idim] <- 0.0
    }
    else
    {
      PS[idim] <-hprecip[idim]*skorr
      PR[idim] <-0.0
    }
    
    MW[idim] <- CX*(htemp[idim]-TS)        # snow melt, degreeday melting
    MWGLAC[idim] <- CGLAC*(htemp[idim]-TS) #glacier melt, degreeday melting
    if(htemp[idim] < TS)
    {
      MW[idim] <- MW[idim]*CFR #negative melt is turned into snow
      MWGLAC[idim] <-0.0
    }
  }

resultRSSM <-NULL
resultRSSM$PR <- PR          #Rain
resultRSSM$PS <- PS          #Snow
resultRSSM$MW <- MW          #Snowmelt
resultRSSM$MWGLAC <- MWGLAC      #Glaciermelt
resultRSSM
}
