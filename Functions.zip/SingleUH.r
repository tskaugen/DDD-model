#    Function SingleUH
#
#------------------------------------------------------------------------
#     Description:  Calculates unit hydrograph from distance information and celerity. 
#
#     Author: Thomas Skaugen
#     Revised: 16.11.2017
#--------------------------------------------------------------------------


SingleUH <- function(k,Timeresinsec,meanD,maxD, nugget) 
{
          
ant <- trunc(maxD/(k*Timeresinsec))+1
UHvec <- vector("numeric",ant) 
escl <-(meanD/k)/Timeresinsec                                 #Parameter in travel time distribution
UHvec[1:ant] <- nugget + (1-nugget)*dexp(0:(ant-1),1/escl)    #Makes exponential pdf.  UH is 1/e1ascl*exp(-(1/e1ascl)*t)/sum_for_all_t(1/e1ascl*exp(-(1/e1ascl)*t))
UHvec[1:ant] <- UHvec[1:ant]/sum(UHvec)                       #Must normalise so that the sum equals 1

resultUH <-NULL
resultUH <- UHvec                                             #Unit hydrograph, i.e. weights distributing runoff in time 
resultUH
}
