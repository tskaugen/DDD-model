Sensible_lat_heat <-function(P,Ta,Timeresinsec,u,Tss,Pa)
{
#Innparametere:
#TS: sn�temperatur
#Ta: d�gnmiddeltemperatur/aktuell temperatur
#Timeresinsec:Tidsoppl�sning i sekunder
#Tidsoppl�ningsbestemte parametere: rh og rv
#Tss i denne rutinen er midlere sn�pakketemperatur
#F�lbar varme

ca <-1.01 #varmekap luft kJ/kgK, p197 i Dingmann
rhoa <- 1.29 #kg/m3
#ifelse(Ta>0,Tss <-0.0,Tss <- Ta) #Sn�overflatetemperatur

zu <- 10 # H�yde p� vind m�linger
zt <- 2 # H�yde p� lufttemperatur m�linger
zm <- 0.0005# ruhetsparameter for sn�
d <-0 # Zeroplane displecement for snow
zh <- 0.0002 # varme og damp ruhets
k <- 0.4#von Karmans konstant
common <- k^2/(log((zu-d)/zm))^2
H <- ca*rhoa*common*u*(Ta-Tss) # dette kommer ut som positivt hvis Tss < Ta (Det samme gjelder for Latent varme) 0.5, adjusting for for stable atm conditions

#Latent varme
#Wa <- 0.8349 #mean value relative humidity
Wa <- CloudCover(Ta,P)$Wa #Ta er ikke riktig, men brukes ikke i CloudCover enn�
ea <- 0.611*exp((17.3*Ta)/(Ta+237.3))*Wa #alltid positivt. endret fra 273.3 25.10.2016 endret med middel av observert RH @Filefjell, p.31 Kristina
es <-  0.611*exp((17.3*Tss)/(Tss+237.3))#alltid positivt.endret fra 273.3 25.10.2016
LaV <- 2470#kJm^2latent varme fra fordampning
LaF <-334 #kJ latent varme fra fusjon

if(Tss < 0.0)
{
LE <-(LaV+LaF)*0.622*(rhoa/Pa)*common*u*(ea-es)
}
if(Tss >= 0.0)
{
LE <-(LaV)*0.622*(rhoa/Pa)*common*u*(ea-es)
}

H <- 1.0*H*Timeresinsec #0.5, adjusting for for stable atm conditions
LE <-1.0* LE*Timeresinsec

resultSensible_lat_heat <-NULL
resultSensible_lat_heat$H <-H
resultSensible_lat_heat$LE <-LE
resultSensible_lat_heat$RH <-Wa
resultSensible_lat_heat
}