#    Function readPrecipTemp
#
#------------------------------------------------------------------------
#     Description:  Extracts precipitation and temperature from ptq file 
#
#     Author: Thomas Skaugen
#     Revised: 20.11.2017
#--------------------------------------------------------------------------


ReadPrecipTemp <- function(ptqinn,hprecip,htemp) 
{

  hprecip[1] <-ptqinn$p01 
  hprecip[2] <-ptqinn$p02 
  hprecip[3] <-ptqinn$p03 
  hprecip[4] <-ptqinn$p04 
  hprecip[5] <-ptqinn$p05 
  hprecip[6] <-ptqinn$p06 
  hprecip[7] <-ptqinn$p07 
  hprecip[8] <-ptqinn$p08 
  hprecip[9] <-ptqinn$p09 
  hprecip[10] <-ptqinn$p10 
  
  htemp[1]  <-ptqinn$t01  
  htemp[2]  <-ptqinn$t02
  htemp[3]  <-ptqinn$t03
  htemp[4]  <-ptqinn$t04
  htemp[5]  <-ptqinn$t05
  htemp[6]  <-ptqinn$t06
  htemp[7]  <-ptqinn$t07
  htemp[8]  <-ptqinn$t08
  htemp[9]  <-ptqinn$t09
  htemp[10]  <-ptqinn$t10          


resulRPT <-NULL
resulRPT$hprecip <- hprecip                   #precipitation pr elevation zone 
resulRPT$htemp <- htemp                   #temperature pr elevation zone
resulRPT
}
