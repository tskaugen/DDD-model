Smelt_eb <-function(DN,PR,PS,Ta,SWE,Timeresinsec,Temp,thr,u,taux,Pa,snittT, phi, thi)
{

PR <- PR/1000.0 #[m]
SWE <- SWE/1000.0 #[m]
regn <- PR+PS

 fraSnowpack_temp <- Snowpack_temp(Temp)
 snittT <- fraSnowpack_temp$snittT# Gir snitttemperatur i sn�pakke som brukes for � beregne overflatetemp
# Tss <- snittT*2                  # Overflatetemperatur, forutsetning at jordoverflatetemp er 0.0
#Tss <- min (0,(snittT + Ta)/2)                  # Overflatetemperatur, forutsetning at jordoverflatetemp er 0.0

FraTss_dewpoint <- Tss_dewpoint(Ta,regn)
Tss <- FraTss_dewpoint$Tss
if(Tss > 0.0)
{
  if(SWE > 0.0) Tss <- 0.0
}
#snittT <- Tss*0.5

#print(paste("Ta= ",Ta, "Tss= ", Tss))

#ShortWave
frasolrad_trans_albedo <- solrad_trans_albedo(DN,Ta,taux,SWE,regn,thr,Timeresinsec,Tss,PS,phi,thi, Temp)# Walter and UEB albedo 
SWrad <-frasolrad_trans_albedo$S       #Net radiation appears to be OK. sr,ss Trans,zen_ang,theta, theat2 checked at 1h res and found to be OK
A <- frasolrad_trans_albedo$A
taux <- frasolrad_trans_albedo$taux
#Sinn <- frasolrad_trans_albedo$Sinn
#Aprim <- frasolrad_trans_albedo$Aprim
#theta <-frasolrad_trans_albedo$theta
#theta2 <-frasolrad_trans_albedo$theta2
#sr <-frasolrad_trans_albedo$sr
#ss <-frasolrad_trans_albedo$ss
#Trans <- frasolrad_trans_albedo$Trans
#zen_ang <-frasolrad_trans_albedo$zen_ang

#print(paste("thr=",thr,"sr=",round(sr,2),"ss=",round(ss,2),"Trans=", round(Trans,3),"zen_ang=",round(zen_ang,4)))


#LongWave
fraLong_wave_rad <-Long_wave_rad(regn,Ta,Timeresinsec,Tss,SWE,mean(Temp))# uses Snow surface temperature, TSS
LWradA <- fraLong_wave_rad$LA #Atmosphere
LWradT <-fraLong_wave_rad$LT #Terrestrial
Cl <- fraLong_wave_rad$Cl

#Heat
fraSensible_lat_heat <-Sensible_lat_heat(PR,Ta,Timeresinsec,u,Tss,Pa)    #uses Snow surface temperature, TSS
SH <- fraSensible_lat_heat$H #Short
LE <- fraSensible_lat_heat$LE
RH <- fraSensible_lat_heat$RH

#Ground_prec_CC
fraGround_prec_CC <- Ground_prec_CC(SWE,Ta,PR,Timeresinsec,snittT,PS)
GH <- fraGround_prec_CC$G
PH <- fraGround_prec_CC$PH
CC <-fraGround_prec_CC$CC
SPtemp <- fraGround_prec_CC$SPtemp
rhow <- 1000 #[kgm^-3]
lam <- 334 #kJkg^-1 latent heat of fusion    se Dingman p.190
#melt <- 1000* (SWrad+LWradA-LWradT+SH+LE+GH+PH+CC)/(lam*rhow) #potential melt in mm
if (CC==0.0) melt <- 1000* (SWrad+LWradA-LWradT+SH+LE+GH+PH+CC)/(lam*rhow) #potential melt in mm
if (CC > 0.0) melt <-0.0

#print(paste("SWrad=",round(SWrad,2), "LWradA=",round(LWradA,2),"LWradT=",round(LWradT,2),"SH=",round(SH,2),"LE=",round(LE,2),"GH=",GH,"PH=",PH,"CC=",CC))
#print(paste("melt[mm]=",round(melt,2),"netSWwatt=",round(SWrad*1000/Timeresinsec,2),"snittT=", round(snittT,3),"Ta=",Ta, "A=", round(A,4)))

ci <- 2.102 #kJ/kgK heat capcacity of ice Dingman. p. 189
#if (melt < 0)
  #correcting snowpack temperature for minus degrees in snowpack and melt!
#  if(SWE > 0.0){
#    
#    deltaT <- (melt*lam)/(((SWE*1000)+PS)*ci) # Eq. 25 in Skaugen and Saloranta, 2015) degrees
#     
#   if (snittT > (snittT+ deltaT))snittT <- snittT + deltaT #inkluderer denne 25.10.2016, kj�ler ned?
#   #  print(paste("snittT=", round(snittT,3),"deltaT=",round(deltaT,3)))
#   TSS <- 2*snittT
#   #LongWave
#   fraLong_wave_rad <-Long_wave_rad(regn,Ta,Timeresinsec,Tss,SWE,mean(Temp))# uses Snow surface temperature, TSS
#   LWradA <- fraLong_wave_rad$LA #Atmosphere
#   LWradT <-fraLong_wave_rad$LT #Terrestrial
#   
#   #Heat
#   fraSensible_lat_heat <-Sensible_lat_heat(PR,Ta,Timeresinsec,u,Tss,Pa)    #uses Snow surface temperature, TSS
#   SH <- fraSensible_lat_heat$H #Short
#   LE <- fraSensible_lat_heat$LE
#   
#   #Ground_prec_CC
#   fraGround_prec_CC <- Ground_prec_CC(SWE,Ta,PR,Timeresinsec,snittT,PS)
#   GH <- fraGround_prec_CC$G
#   PH <- fraGround_prec_CC$PH
#   CC <-fraGround_prec_CC$CC
#   SPtemp <- fraGround_prec_CC$SPtemp
#   rhow <- 1000 #[kgm^-3]
#   lam <- 334 #kJkg^-1 latent heat of fusion    se Dingman p.190
#   melt <- 1000* (SWrad+LWradA-LWradT+SH+LE+GH+PH+CC)/(lam*rhow) #potential melt in mm
# }


if(snittT < 0.0)melt <-0.0
if (SWE==0) melt <-0.0 #Test 21.10 2016

resultSmelt_eb <-NULL
resultSmelt_eb$melt <-melt
resultSmelt_eb$SWrad <-SWrad# nettokortb�lgetstr�ling inn
#resultSmelt_eb$Sinn <- Sinn #kortb�lget inn
resultSmelt_eb$LA <-LWradA
resultSmelt_eb$LT <-LWradT
resultSmelt_eb$SH <-SH
resultSmelt_eb$LE <-LE
resultSmelt_eb$GH <-GH
resultSmelt_eb$PH <-PH
resultSmelt_eb$CC <-CC
resultSmelt_eb$A <-A
resultSmelt_eb$taux <- taux
#resultSmelt_eb$Aprim <- Aprim
resultSmelt_eb$snittT <- snittT
resultSmelt_eb$Tss <- Tss
resultSmelt_eb$Cl<- Cl
resultSmelt_eb$RH <- RH
#resultSmelt_eb$ss<- ss
#resultSmelt_eb$Trans <- Trans
#resultSmelt_eb$zen_ang<- zen_ang
resultSmelt_eb

}