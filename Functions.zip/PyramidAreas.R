
#    Function PyrAreas
#
#------------------------------------------------------------------------
#     Description: Estimates the areas asscociated with each layer at ecach time step due to celerity
#                  A postprocessing routine
#
#     Author:  Thomas Skaugen
#     Revised: 04.01.2018
#--------------------------------------------------------------------------
#----------------------------------------------------------------------------------

PyrAreas <- function(NoL,totarea,maxDl,nodaysvector, layerUH, antHorlag)
{

#See Skaugen and Mengistu(2016)for the rationale behind this subroutine
  #Need to calculate the ratios. 
  # the parameter gamma of the exponential distance distribution is 1/midDL
  # From Skaugen and Mengistu, 2016 we have that the ratio Kappa is related to 
  # gamma= -log(kappa)/delta_d, where delta_d is the distance interval of choice
  # The ratio kappa is then kappa= exp(-gamma*delta_d)=exp(-delta_d/midDL) 
  
  # total area distributed pr Layer
Areas <- matrix(0.0, ncol=antHorlag,nrow=NoL)
  for( i in 1:NoL)
  {
    for (j in 1:nodaysvector[i])Areas[i,j] <- totarea*layerUH[i,j] 
  }
  delta_d <-vector("numeric",NoL)                            # in meters (height as in the pyramid plots) pr. time-step box
  delta_d[1:NoL] <- maxDl/nodaysvector[1:NoL]  
  

#To be used in GRW_point subroutne: Layers__mm <- Layers*totarea/areas ######################

resultPyrAreas <-NULL
resultPyrAreas$Areas <- Areas
resultPyrAreas$delta_d <- delta_d 
resultPyrAreas
}  
 