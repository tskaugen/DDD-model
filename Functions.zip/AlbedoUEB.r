#Denne subrutinen estiemrer albedo etter UEB sin adaptation of that of Dickinson et al. 1993 (BATS, NCAR)

AlbedoUEB <-function(PS,SD,TSS,zenang,taux,Timeresinsec)
{
#rm(list=ls())
#constants from Tarboton and Luce, Utah energy balance Snow Accumulation and Melt Model UEB, 1996
A_bg <- 0.25#Bare ground albedo
C_v <-0.2
C_ir <- 0.5
alfa_v0 <- 0.95
alfa_ir0 <- 0.65
tau0 <- 1000000
h_sd <-0.05# meter
b <-2 #Dickinson et al 1993

##TEST VARIABLE som er input
#PS <- 0.005 #meter sn�fall
#TSS <- -3.2# Sn�overflate temperatur
#zenang <- 0.6 #zenith vinkel i radianer
#SD <- 0.02# sn� i sn�magasin (med PS?)
#taux <- 0.7# lader fra forrige tidsskritt 
#Timeresinsec <- 10800
if (zenang < 0.5) print(paste("zenang_albedo=", zenang))
####
# ved nysn� er tau lik null
if(PS >= 0.01) taux <- 0.0
r1 <- exp(5000*((1/273.16)-(1/(TSS+273.16))))
r2 <-min(r1^10,1)
r3 <- 0.03
d_tau <-  ((r1+r2+r3)/tau0)*Timeresinsec

taux <- taux + d_tau
F_age <- taux/(1+taux)

alfa_vd <- (1-C_v*F_age)*alfa_v0
alfa_ird <- (1-C_ir*F_age)*alfa_ir0

if(cos(zenang) < 0.5)f_omg <- (1/b)*(((b+1)/(1+2*b*cos(zenang)))-1)
if(cos(zenang) > 0.5)f_omg <-0.0

alfa_v =alfa_vd+0.4*f_omg*(1-alfa_vd)
alfa_ir =alfa_ird+0.4*f_omg*(1-alfa_ird)

albedo_init <-0.9*alfa_v+0.1*alfa_ir#vekter det mot visible <0.7 mum, alfa_vd dette gir max albedo p� 0.92

R <-(1-(SD/h_sd))*exp(-(SD/(2*h_sd)))

ifelse(SD < h_sd,albedo <- R*A_bg+(1-R)*albedo_init,albedo <- albedo_init) #interpolerer albedo til bare ground albedo

#print(paste("inne i AlbedoUEB, SD=",SD,"albedo=",albedo ))

resalbedo <- NULL
resalbedo$taux <- taux
resalbedo$albedo <- albedo
resalbedo
}
