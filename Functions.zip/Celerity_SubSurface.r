#    Function Celerity_SubSurface
#
#------------------------------------------------------------------------
#     Description:  Calculates Sub surface celerities based on recession analysis (lower case Lambdas). 
#
#     Author: Thomas Skaugen
#     Revised: 17.11.2017
#--------------------------------------------------------------------------


Celerity_SubSurface <- function(NoL, Gshape, Gscale, midDL, Timeresinsec) 
{
k <- vector("numeric",NoL)                   #celerity of subsurface (and overland) flow
k[1:NoL]<- 0.0
dp <- 1/(NoL-1)                              #Overland flow level (nol=1], fixed celerity and extremely high capacity(2000 mm)
probvec <- vector("numeric", NoL)            #all leves and overland flow level
for(i in 1:(NoL-1))probvec[i+1] <-i*dp-dp/2  #celerities are estimated at center of level, hence dp/2
probvec <- 1-probvec
probvec[1] <-0.99                            #Quantile in celerity distribution for overland flow fixed at 0.99

k[1:NoL] <-qgamma(probvec[1:NoL],Gshape,1/Gscale)*midDL/Timeresinsec

resultCel <-NULL
resultCel <- k                                                #Celerities [m/s] 
resultCel
}
