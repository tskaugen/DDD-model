#Function nedb
#Denne funksjonen har input:
#P               : nedb�r i mm
#TMAX, TMIN      :max og min temperatur erstattes med T
#TX              :skilletemp regn/sn�
#TS		     : skilletemp smelting/frysing
#CX              :Temperaturindex for smelting
#CFR		     :Correksjonsfaktor for CX for refrysing
#pskorr,prkorr    :korreksjonsfaktorer for nedb�r og sn�

#og Output:
#MW              :potenial melt/refreeze(negative) mm
#PR		     :nedb�r som regn
#PS              : nedb�r som sn�

nedb_eb <-function(DN,P,Ta,SWE,Timeresinsec,Temp,TX,prkorr,pskorr,thr,u,Pa,CGLAC,taux,snittT,phi,thi)
 
{

#Nedb�r eller sn�?
    if(Ta > TX)
    {
      PR <-P*prkorr
      PS <- 0.0
    }
    else 
    {
      PS <-P*pskorr
      PR <-0.0
    }
#beregner sn�pakkas temperatur, kan justeres nedover hvis EB tilsier at vi har negativ smelting
     fraSnowpack_temp <- Snowpack_temp(Temp)
     snittT_a <- fraSnowpack_temp$snittT# Gir snitttemperatur i sn�pakke
     #if(snittT_a < snittT)snittT <- snittT_a # bruker den laveste temperaturen
     snittT <- snittT_a
#merk at hvis albedoUEB brukes er Aprim egentlig forriges tidsskritts sn�alder, taux
     fraSmelt_eb <-Smelt_eb(DN,PR,PS,Ta,SWE,Timeresinsec,Temp,thr,u,taux,Pa,snittT,phi,thi)
     MW <- fraSmelt_eb$melt           #potential melt
     SWrad <- fraSmelt_eb$SWrad       #net radiation
     #Sinn <- fraSmelt_eb$Sinn 
     LA <- fraSmelt_eb$LA
     LT<- fraSmelt_eb$LT
     SH <-fraSmelt_eb$SH
     LE <-fraSmelt_eb$LE
     GH <- fraSmelt_eb$GH
     PH <-fraSmelt_eb$PH
     CC <-fraSmelt_eb$CC
     A <- fraSmelt_eb$A
     #Aprim <- fraSmelt_eb$Aprim
     taux <- fraSmelt_eb$taux
     snittT <- fraSmelt_eb$snittT
     Tss <- fraSmelt_eb$Tss
     RH <- fraSmelt_eb$RH
     Cl <-fraSmelt_eb$Cl 
     #Trans <- fraSmelt_eb$Trans
     #zen_ang <-fraSmelt_eb$zen_ang
     
     TS <-0.0
     CFR <- 0.02
     MWGLAC <- CGLAC*(Ta-TS)#Smelting fra bre
     #MWGLAC <- CX*(Ta-TS)
    if(Ta < TS)#smelting (MW) kommer ut som negativ
    {
      MW <- MW*CFR #kommer ut som negativ verdi og er antall mm som gjenfryses
      MWGLAC <-0.0
    }      

#returnerer resultater
resultvinn <-NULL
resultvinn$PS <-PS
resultvinn$PR <-PR
resultvinn$MW <-MW
resultvinn$MWGLAC <-MWGLAC
resultvinn$SWrad <-SWrad
#resultvinn$Sinn <-Sinn
resultvinn$LA <-LA
resultvinn$LT <-LT
resultvinn$SH <-SH
resultvinn$LE <-LE
resultvinn$GH <-GH
resultvinn$PH <-PH
resultvinn$CC <-CC
resultvinn$A <-A
#resultvinn$Aprim <-Aprim
resultvinn$taux <-taux
resultvinn$snittT <-snittT
resultvinn$Tss<- Tss
resultvinn$Cl <- Cl
resultvinn$RH<- RH
#resultvinn$ss <- ss
#resultvinn$Trans<- Trans
#esultvinn$zen_ang <- zen_ang
resultvinn
}