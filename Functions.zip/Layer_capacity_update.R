#    Function Layer_capacity
#
#------------------------------------------------------------------------
#     Description:  Calculates current capacity in groundwater layers. 
#
#     Author: Thomas Skaugen
#     Revised: 16.11.2017
#--------------------------------------------------------------------------

Layer_capacity_update <-function (Layers, nodaysvector, Magkap, NoL, ddistx, aktMag)
{
ddistx[1:NoL] <- 0.0
aktMag[1:NoL] <- 0.0

#Below are the states (in mm) for each saturation level
for (j in NoL:1)
{  
  #state after this timestep water is gone. amount of water  in mm, minus current timestep
  aktMag[j] <-sum(Layers[j,2:nodaysvector[j]])
  # ddistx informs on current capacity for each level in mm.
  if (aktMag[j] < Magkap[j]) ddistx[j] <- Magkap[j]- aktMag[j]
}

utLayercap <-NULL
utLayercap$ddistx <- ddistx
utLayercap
}
