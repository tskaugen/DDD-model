Long_wave_rad <-function(P,Ta,Timeresinsec,Tss,SWE,Temp)
{
#Innparametere: Nedb�r og temperatur
#Tidsoppl�ningsbestemte parametere Boltzmanns konstant
#emissivity er dimasnjonsl�s
#Long wave radiation
#ifelse(P > 0, Cl <- 1.0, Cl <-0.1) #Cloudcover 100 % if precipitation, zero otherwise Litt brutal, ganske mange skyete dager
  
Cl <- CloudCover(Temp,P)$Cl
#Wa <- CloudCover(Temp,P)$Wa

#Noter at Cl = 0.1 hvis skyfritt, min justering

#epsa <-(0.72+0.005*Ta)*(1-0.84*Cl)+0.84*Cl#Emissivity From Walter et al.

#Ny 24.10.2016 fra Filefjell empiri
epsa <- (1.0+0.0025*Ta)-(1-Cl)*(0.25*(1.0+0.0025*Ta))# Quite good, using the RH modelling?
if(epsa >1.0) epsa <- 1.0

#Ny Kustas et al. 1994, 14022018
#Wa <- CloudCover(Ta,P)$Wa
#ea <- 0.611*exp((17.3*Ta)/(Ta+237.3))*Wa 
#epsa <- 1.72*(ea/(Ta+273.2))^0.14285*(1+0.22*Cl^2)

#if(Cl >= 0.65)epsa <- 1-1.38*Cl+ 1.33*Wa*Cl # Cloudy conditions  from Herrero and Polo(HESS, 2012) #Terrible!!
#if(Cl < 0.65)epsa <- 0.81-0.26*Cl^2+0.25*Wa^3  #Partly cloudy                                # mean values from Filefjell
#if(Cl < 0.4)epsa <- -1.17+ 0.16*Wa+0.0062*Ta # Clear sky conditions


sigma <- 4.89*10^-6 #Boltzmans konstant pr dag!
sigma2 <- (5.67*10^-11)*Timeresinsec#kJ/m^2*s*K^4, pr sekund

LA <-epsa*sigma2*(Ta+273.2)^4#Ta skal v�re i Celsisus. Atmosf�risk innsts�ling Walter

#if(SWE==0) Tss <- Ta #Hvis sn� er borte, s� blir jordtemp gjennomsnittet fra de siste 5 dager
LT <-0.97*sigma2*(Tss+273.2)^4 + (0.03*LA) # terrestrisk utstr�ling emmisivity for sn� er 0.97, er ogs� brukt for bare ground, se Dingman p.583


#Gir verdier av riktig st�rrelsesorden og balanserer hverandre s�nn passe

resultLong_wave_rad <-NULL
resultLong_wave_rad$LA <-LA
resultLong_wave_rad$LT <-LT
resultLong_wave_rad$Cl <-Cl
resultLong_wave_rad
}