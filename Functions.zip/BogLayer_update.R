#    Function Layer_update
#
#------------------------------------------------------------------------
#     Description:  Updates Layers by todays event and shifting to one timestepahead. 
#
#     Author: Thomas Skaugen
#     Revised: 2817.9.2018
#--------------------------------------------------------------------------

BogLayer_update <-function (outbog, BogLayers, UHBog, nodaysvector)
{
  
    qlayer <-outbog*UHBog    #finds response  in mm!!!!  for bog, en vektor     
    if(nodaysvector >1)
    {
      BogLayers[1:(nodaysvector-1)] <- BogLayers[2:nodaysvector] + qlayer[2:nodaysvector]# flytter the level of the matrix one timestep ahead
      BogLayers[nodaysvector] <-0.0
      #BogLayers[1:(nodaysvector-1)] <- BogLayers[1:(nodaysvector-1)] + qlayer[2:nodaysvector] # update with todays event
    } 
    if(nodaysvector ==1)BogLayers[1:nodaysvector] <- qlayer

BogLayerUpdate <- NULL
BogLayerUpdate$BogLayers <- BogLayers
BogLayerUpdate
  
}
