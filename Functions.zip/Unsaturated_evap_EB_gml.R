#    Function Unsaturated_evap(isoilx,sncovx,smx,outx,ceax,tempx,lp,ep)
#
#C------------------------------------------------------------------------
#
#     Description: Calculates soil moisture (unsaturated) and evapotranspiration (Priestley-Taylor)
#     Author: Thomas Skaugen
#     Revised: 09.3.2018
#
#     Parameters:
#     EA       Actual evapotransp
#     CEA      Evaporation constant[mm/deg/day]   
#     MIDDELSCA    Snowcovered area
#     sm       Soil moisture content, mm
#     D       Saturation deficit (D>Z) mm
#     M       Total sudsurface water reservoir mm
#     OUTX      Outflow form soil moisture reservoir mm/d
#     Constant
#     R       A fraction volumetric Water content 30 %
#     
#--------------------------------------------------------------------------

Unsaturated_evap_EB <- function(toSoil,eatemp,middelsca,sm,M,D,ET)
{

      R <- 0.3     
      outx <- 0.0

#-------------------------------------------------------------------------
#  Actual evapotranspiration
#-------------------------------------------------------------------------
      if (eatemp > -10.0) #Function of temp, areal mean, see S�lthun 1996, p. 9
        #ET is potential evapotranspiration which becomes actual due to deficit, Priestly Taylor
        # ea has priority and should not be limited by sm  (sm should rather be a constant, R* M-D)
      {
        ea<-min(ET, ET*((M-D+sm+toSoil)/M))#*(1.0-middelsca)
        toSoil <- max(0,toSoil-ea)                 # reducing input available to sm and runoff 
      }
      else
      {
        ea <-0.0
      }   
#--------------------------------------------------------------------------------------------------------
#     Estimating retention of moistureinput to sm and runoff
#     The theory is that saturated and unsaturated sone share the same volume, and are hence the complement
#     of each other 
#--------------------------------------------------------------------------------------------------------      
      
      ifelse(D > 0, rat <-(sm+toSoil)/D, rat <-1) #taking into account that D can be zero or even negative (overland flow), complete saturation.
      
      if(rat > R)
      {
        outx <-(sm+toSoil)-R*D
        sm <-R*D
      }
      else
      {
        outx <- 0
        sm <- sm+toSoil
      }        
        
resultmark <-NULL
resultmark$outx <-outx
resultmark$sm <-sm
resultmark$ea <- ea
resultmark
}

     