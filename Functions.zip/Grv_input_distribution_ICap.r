# Funstion for distributing input to the differnt groundwater layers according to their individual
# level of saturation
#
# Author: Thomas Skaugen
# Revised: 16.11.2017
#################################################################################################
                                       
# ddist provides the weights to distribute outx to different layers
# The sum of ddist[1:NoL] is always 1 and the higher ddist the more water is received by the layer
# This subroutine takes into account Infiltration capacity ICap

################################################################################################


Grv_input_distribution_ICap <- function(outx, NoL,ddistx, ddist, ICap)
{
 
#   ICap <- 2.070
  #ICap <- 0.042
  #NoL <-5
  #ddistx <- c(2000, 0.9555267, 0.2208195, 0.1399240, 0.09650506)
#  ddistx <- c(1999.6,0.904 , 0.0058, 0.0020, 0.0000)
 #ddist <- c(0,0,0,0,0)
 #outx <-1.676167
  
defi <- sum(ddistx[2:NoL])             # deficit in subsurface
if(ICap < outx)                        # OF due to exceedance of ICap, In additin we may have OF flom below
 {
    OF <- outx-ICap                    # what cannot be infiltrated goes to overland flow. In addition, saturation from below also gives OF
    if(defi < ICap)OF <- OF + (ICap-defi) # In addition, saturation from below also gives OF
    redoutx <- ICap 
 
 }
if(ICap >= outx)                     # everything infiltrates an we may have OF from below
 { 
   OF   <-0.0
   if(defi < outx) OF <- outx-defi     # In addition, saturation from below also gives OF
   redoutx <-outx-OF                # in case OF is  null this is OK, and if OF is greater than null it is also OK since outx is always larger than OF
 }   

#redoutx <- outx                      # outx is reduced sucessively by the layers, starting from the slowest, NoL
ddist[1:NoL] <- 0.0
if(outx >0.0)
{
  
if(OF > 0.0) ddist[1] <- OF/outx                   # assigning distribution of outx to overland flow layer layer 1


   for (j in NoL:2)                   # Remember NoL is the slowest layer, 1 is the fastest and already accounted for
   {
    if(redoutx > 0.0)
    {
       differ <- ddistx[j]-redoutx
       if (differ < 0)                #i.e the deficit i layer j is less than input, input(outx (redoutx)) > deficit
       {
         ddist[j] <-ddistx[j]/outx    # divide by outx informs us what frafction of outx needed for this layer
         redoutx <- redoutx-ddistx[j] # must reduce  the input correspondingly       
       }
       if (differ >= 0)               # i.e. deficit in layer j is more than input
       {
         if (j < NoL) ddist[j]  <-  1.0 - sum(ddist[(j+1):NoL])-ddist[1]  #ddist[1] is already assigned
         if (j==NoL) ddist[j] <-1.0-ddist[1]                              #ddist[1] is already assigned
#if(j >1) ddist[(j-1):1] <-0.0  # We allow for layer 1 (overland flow layer) receives the rest in case input>layer capacity. Does no longer apply!
         redoutx <- 0.0
       }
    
    }
  }    
}    
#print(ddist)
#print(ddist*outx)
#print(sum(ddist))
  
resultInp <- NULL
resultInp$ddist <- ddist   #fractions
resultInp
} #end of func
