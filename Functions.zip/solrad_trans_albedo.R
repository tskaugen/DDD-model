solrad_trans_albedo <-function(DN,Ta,taux,SWE,regn,thr,Timeresinsec,TSS,PS,phi,thi,Temp)
{
# input til subrutine er:
#Dagnummer
#x, y koordinat i UTM 33
#maximums temperatur
#minimums temperatur
#D�gnmiddel temperatur
#phi <- 1.059332 #h�lervann 12.171
#thi <- 0.1628135 #h�lervann 12.171
#Albedo fra dagen f�r
#Sprim og Albedo er daglige bestemt for daglige verdier verdierTemoral oppl�sning er bestemt av
 
deltaSWE <-PS/1000.0
thrx <-thr          #The time step for this calculation (in hours)
if(thr==0)thrx <-24 #1.2.2013

ddphi <- phi*180/pi #latitude decimal degrees
ddthi <- thi*180/pi #longitude decimal degrees
#print(paste("breddegrad(lat)=", round(ddphi,5),Timeresinsec))
#print(paste("lengdegrad(long)=", round(ddthi,5)))
gamma <- (2*pi/365)*(DN-1)
#DN <-173
#thetaW <- 0.4102*sin((2*pi/365)*(DN-80))#solar declinati0on angleday angle, Walter 2005
#print(paste("sol.decl.angle=",thetaW,"daynumber=", DN))
#thetaDing <- (180/pi)*(0.006918-0.399912*cos(gamma)+0.070257*sin(gamma)-0.006758*cos(2*gamma)+0.000907*sin(2*gamma)-0.002697*cos(3*gamma)+0.00148*sin(3*gamma))
#theta <- vector("numeric", 365)
#theta2 <- vector("numeric", 365)
#for (DN in 1:365)theta[DN] <- 0.4092*cos((2*pi/365)*(DN-173))#solar declinati0on angleday angle Liston 1995
#for (DN in 1:365)theta2[DN] <- 0.4102*sin((2*pi/365)*(DN-80))#solar declinati0on angleday angle 
  theta <- 0.4092*cos((2*pi/365.25)*(DN-173)) #solar declinati0on angleday angle Liston 1995 

  theta2 <- 2*pi/365.25*(DN-80)
  
  r <-149598000#distance from the sun [km]
  R <- 6378 #Radius of earth [km]
  timezone <- -4*(abs(thi)%%15)*sign(thi)#ang lengdegrad ikke 
  epsilon <- 0.4092 #rad(23.45)
  z.s <-r*sin(theta2)*sin(epsilon)
  r.p <- sqrt(r^2-z.s^2)   #her
  nevner <- (R-z.s*sin(phi))/(r.p*cos(phi)) 
  
  if((nevner > -1) && (nevner < 1))
  {
   # acos(m� ha inn verdier ,(mellom-1,1) hvis <-1 s� er det midnattsol > 1 er det m�rketid.
   t0 <-1440/(2*pi)*acos((R-z.s*sin(phi))/(r.p*cos(phi)))
   that <- t0+5
   n <-720-10*sin(4*pi*(DN-80)/365.25)+8*sin(2*pi*DN/365.25)
   sr <-(n-that+timezone)/60 #soloppgang
   ss <- (n+that+timezone)/60 #solnedgang
  }

if (nevner <= -1) #Midnattsol
{
 sr <-0.0
 ss <-24.0
}

if (nevner >= 1) #M�skjetid
{
 sr <-12.0
 ss <-12.0
}


TTList <- vector("numeric",24) #vektor for Transmissivity
dingom <- vector("numeric",24) #vector for solar elevation angle

for (tid in 1:24)
{
  if((tid > sr) && (tid < ss))
  {
  #ifelse(regn > 0, Cl <- 1.0, Cl <-0.1) #Cloudcover 100 % if precipitation, zero otherwise Litt brutal, ganske mange skyete dager
  Cl <- CloudCover(Temp,regn)$Cl
  #Cl <-0.5  
  #Noter at Cl = 0.1 hvis skyfritt, min justering

  tom <-  -(12-(tid)) #gir antall timer fra solar noon, som gir tom=0.0
  #print(tom)
   cosarg <-0.2618 *tom #radianer pr time
  #dingom<- vector("numeric", 365)
   dingom[tid] <- acos(sin(phi)*sin(theta)+cos(phi)*cos(theta)*cos(cosarg))  #Dingmans zenith angle
   #TTList[tid] <- (0.6 + 0.2*sin((0.5*pi)-dingom[tid]))*(1.0-0.5*Cl) #Inspirert av G. Liston 1995 transmissivitet. Gir h�ye verdier
   #TTList[tid] <- (0.6 - 0.3*sin(dingom[tid]))*(1.0-0.5*Cl) #Inspirert av G. Liston 1995 transmissivitet. Gir lave verdier
   TTList[tid] <- (0.5 + 0.3*cos(dingom[tid]))*(0.2 +0.68*(1-Cl)) #Inspirert av Bacellar 2008 transmissivitet og Dingman (Skyer) Skal ned i 0.15 ved overcast (Bacellar).
  } 
  if((tid < sr) || (tid > ss))  #If time is outside sunrise sunset
  {
     TTList[tid] <-0.0 #Transmissivity Disse settes lik null hvis solen er under horisonten
     dingom[tid] <-pi*0.5 #pi/2 minus zenith angle, Blir veldig lav med init dingom lik pi/2
     #blir p� den annen side h�y med init dingom lik 0 . Albedo ser ganske fornuftig ut
  }
}

if(Timeresinsec == 86400) 
{ 
    Trans <- mean(TTList)
    zen_ang <- mean(dingom)
}

if(Timeresinsec < 86400)#Midler transmissvitet og solvinkel For finere tidssoppl�sning
{
interv <-as.integer(Timeresinsec/3600)#how many hours?
if (interv < 1) interv <- 1           #This calculation is only carried out for hourly values 
Trans <- mean(TTList[(thrx-interv+1):thrx])
zen_ang <- mean(dingom[(thrx-interv+1):thrx])
}
#th30 <- 0.4102*sin((2*pi/365)*((DN-30)-80)) 
#Sprim <-117.6*10^3 #[kJ/m^2*day]Sola constant
S0 <- (118.1*10^3)/86400 #kJ/m2*s. Tall fra Dingman
 
S0 <- S0*Timeresinsec #solar constant pr timeunit                             #STATIC should be moved
#print(paste("Solar constant=", S0,Timeresinsec))

#Albedo M� ta med dagens sn� for � regne ut albeo, eller smelter den bare vekk
SD <- (1000/300)*(SWE+deltaSWE) #[m] bruker 300 kg/m3 som fast tetthet for utregning av albedo i UEB SDi [m]
#UEB albedo
albUEB <- AlbedoUEB(PS,SD,TSS,zen_ang,taux,Timeresinsec)
A_UEB <- albUEB$albedo
#print(paste("Albedo=",A,"SD=",SD,"taux=",round(taux,3)))
taux <- albUEB$taux

#Todd Walters albedo
#print(paste("deltaSWE=",deltaSWE,"SWE=",SWE,"taux=",round(taux,3)))
#albW <- AlbedoWalter(deltaSWE,SWE,Ta,Aprim,Timeresinsec,thrx)
#A_Walter <- albW$albedo
#Aprim <-albW$Aprim

#her velger jeg hvilken albedo variant
A <-A_UEB
#A <-A_Walter

#Solar radiation
S <-(1-A)*Trans*sin((pi/2)-zen_ang)*S0 #se likning Liston 1995, eq. 26 (NettoSWstr�ling)
Sinn <-Trans*sin((pi/2)-zen_ang)*S0

#print(paste("zenang_solrad=",zen_ang))

resultsolrad_trans_albedo<- NULL
resultsolrad_trans_albedo$S<- S
resultsolrad_trans_albedo$Sinn<- Sinn
resultsolrad_trans_albedo$A<- A
#resultsolrad_trans_albedo$Aprim<- Aprim
resultsolrad_trans_albedo$taux<- taux
resultsolrad_trans_albedo$theta<- theta
resultsolrad_trans_albedo$theta2<- theta2
resultsolrad_trans_albedo$sr<- sr
resultsolrad_trans_albedo$ss<- ss
resultsolrad_trans_albedo$Trans<- Trans
resultsolrad_trans_albedo$zen_ang<- zen_ang
resultsolrad_trans_albedo
}

