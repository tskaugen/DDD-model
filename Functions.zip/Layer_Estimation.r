#    Function Layer_Estimation
#
#------------------------------------------------------------------------
#     Description:  Calculates the total capacity of groundwater reservoir and for its Layers  
#
#     Author: Thomas Skaugen
#     Revised: 17.11.2017
#--------------------------------------------------------------------------

Layer_Estimation <- function(GshInt,GscInt,Timeresinsec,maxDl,midDL, MAD, area2, NoL, gtcel)
{

mLam <- GshInt*GscInt
varLam <- GshInt*(GscInt)^2                      #Yevjevich p.145
meanIntk <- mLam*midDL/Timeresinsec              #mean celerity estimated through Integrated Celerity
antBox <- trunc(maxDl/(meanIntk*Timeresinsec))+1 #Temporal length UH_MAD
UH_MAD <- vector("numeric", antBox)
sRes <-  vector("numeric", antBox) # saturation sum
#Unit hydrograph for MAD
UH_MAD <- SingleUH(meanIntk,Timeresinsec, midDL, maxDl, 0)

StSt<- (1000*MAD*Timeresinsec)/(area2)       # Steady state Input eq. output in mm
sRes[1] <-0
sRes[2:antBox] <- StSt*UH_MAD[2:antBox]

for(i in 3: antBox)
{
  sRes[i:antBox] <- sRes[i:antBox] + StSt*UH_MAD[i:antBox]
}
mRes <- sum(sRes)
Fact <- mLam/mRes
stdRes <- (varLam/Fact^2)^0.5                    #see Haan p.51

GshRes <-mRes^2/stdRes^2
GscRes <-stdRes^2/mRes

MLev <-seq(1/(NoL-1),1,1/(NoL-1))               #Quantiles  to calculate reservoir levels
MLev[NoL-1] <- gtcel                            # quantile for start overland flow
Res_prob <- vector("numeric", NoL-1)

#calculates the reservoir levels associated with quantiles. Mean is GshRes*GscRes
Res_prob <- qgamma(MLev,GshRes,1/GscRes)

#Capasity of Layers
ssRes1 <- vector("numeric", NoL)
ssRes1[2:NoL] <- 0.0
ssRes1[1] <-2000                               # capacity of overland flow level

for (i in 2:(NoL-1))
{
  ssRes1[i] <-Res_prob[NoL-i+1]-Res_prob[(NoL-i)]
}
ssRes1[NoL] <- Res_prob[1]                    # capasity for the first slowest level         

Magkap <- ssRes1[1:NoL]                       # capasity for Layers 
M <- Res_prob[NoL-1]                          # Total grounwater reservoir

 OutLayEst <- NULL
 OutLayEst$Magkap <- Magkap# 
 OutLayEst$M <- M                             
 OutLayEst
}