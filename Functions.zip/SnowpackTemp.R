Snowpack_temp <-function(Temp)
{
#Denne funksjonen beregner et vektet (lin�rt avtakende) gjennomsnitt av lufttemperaturen som estimat av sn�pakkens overflatetemperatur
#Det antas at bakkenstemperatur under sn�en er 0 grader slik at sn�pakkas gjennomsnittstemperatur er estT/2
#Temp er tempertur vektor av lengde som tilsvarer N dager (5 er brukt i begynnelsen)
len <- length(Temp)
wgt <- vector("numeric",len)
                               #The temperature vector is organzed such that  the first element is todays temp
for(i in 1:len) wgt[i] <- (len-i+1)/len
#for(i in 1:len) wgt[i] <- 1/len
summen <- sum(wgt)
for (i in 1:len)wgt[i] <-wgt[i]/summen
snittT <- sum(wgt*Temp)          # This is the snowpack temperature. Tss is snittT *2

#snittT <- min(Temp)/2 #(not good)
if(snittT > 0.0)snittT <- 0.0   # Snowpack temperature cannot be more than zero
#snittT <- snittT*0.5            # Snowpack temperature, given that ground temperature is zero
resultSnowpack_temp <-NULL
resultSnowpack_temp$snittT <-snittT
resultSnowpack_temp
}