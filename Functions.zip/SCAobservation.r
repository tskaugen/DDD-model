#    Function SCAobservation
#
#------------------------------------------------------------------------
#     Description:  Extracts SCA from elevation zones 
#
#     Author: Thomas Skaugen
#     Revised: 17.11.2017
#--------------------------------------------------------------------------


SCAobservation <- function(ptqinnyr,ptqinnmnt,ptqinnday,scaobdagsdato,hson, scaobx, scaob) 
{
  for(id in 1:hson)#elevation zones
  {
  scaobx[id] <- -9999
  dag <- as.Date(paste(ptqinnyr,"-",ptqinnmnt,"-",ptqinnday,sep=""))
  datoform <- format(dag,"%Y.%m.%d")
  if(length(which(scaobdagsdato == datoform)) > 0)
  {
    target <- which(scaobdagsdato == datoform)
    if(scaob[target,3] < 5.0)
    {
      scaobx[id] <- scaob[target,id+3]/100
    }
  } 
  }

resultSCAobs <-NULL
resultSCAobs$scaobx <- scaobx          #SCA
resultSCAobs
}
