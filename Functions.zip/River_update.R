#    Function River_update
#
#------------------------------------------------------------------------
#     Description:  Updates water in the river network and shifts to one timestepahead. 
#
#     Author: Thomas Skaugen
#     Revised: 17.11.2017
#--------------------------------------------------------------------------

River_update <-function (vectorlengde,QRivx,qsimutx)
{
  if(vectorlengde >1)
  {
    QRivx[1:(vectorlengde-1)] <- QRivx[2:vectorlengde]
    QRivx[vectorlengde] <-0.0
    QRivx <- QRivx +qsimutx
    QRD <- QRivx[1]               #QRD is Runoff for current timestep
  }
  if(vectorlengde ==1)
  {
     QRivx <-qsimutx
     QRD <- QRivx
  }  

RiverUpdate <- NULL
RiverUpdate$QRivx <- QRivx
RiverUpdate$QRD <- QRD
RiverUpdate
  
}
