#    Function Temperaturevector
#
#------------------------------------------------------------------------
#     Description:  Calculates a temperature vector for snowpack temp estimation 
#
#     Author: Thomas Skaugen
#     Revised: 6.2.2018
#--------------------------------------------------------------------------


TemperatureVector <- function(tempmat,idim,len, STempvec) 
{
  STempvec[1:len] <- tempmat[(len):1,idim]
  
resultTV <-NULL
resultTV <- STempvec                                                #temperatures
resultTV
}
