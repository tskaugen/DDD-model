#    Function Layer_evap
#
#------------------------------------------------------------------------
#     Description:  Calculates evapotranspiration directly from Layers and updates Layers. 
#
#     Author: Thomas Skaugen
#     Revised: 10.10.2018
#--------------------------------------------------------------------------

Layer_evap <-function(Layers, nodaysvector, ET, eatemp, D, sm, M, toSoil, layerUH, NoL)
{
 
  #-------------------------------------------------------------------------
  #  Actual evapotranspiration
  #-------------------------------------------------------------------------
  if (eatemp > -10.0) #Function of temp, areal mean, see S�lthun 1996, p. 9
    #ET is potential evapotranspiration which becomes actual due to deficit, Priestly Taylor
    # ea has priority and should not be limited by sm  (sm should rather be a constant, R* M-D)
  {
    ea<-min(ET, ET*((M-D+sm+toSoil)/M))#*(1.0-middelsca)
    #toSoil <- max(0,toSoil-ea)                 # reducing input available to sm and runoff 
  }
  else
  {
    ea <-0.0
  } 
  #browser()
  #print(paste("ea=", ea))
  
  LayersLast <- Layers
  #Below are the states (in mm) for each saturation level
  redea <- ea
  
  for (j in 1:NoL) # ! is the top(fastest) Layer NoL is the bottom layer
  { 
    if(redea > 0.0)
    {
    if(sum(Layers)>0.0)
    {  
     newLayer <-Layers[j,1:nodaysvector[j]]
     aktMag <-sum(Layers[j,1:nodaysvector[j]]) # this is correct becauseea is a nonintegrated with a continuum variable as opposed to discharge
     differ <-aktMag-redea     
      if (differ > 0.0) # corresponds to that the Layer can take the what is left of the evapotranspiration layer content >ea
      {
        evapUH <- redea*layerUH[j,1:nodaysvector[j]]
        #browser()
        newLayer <- Layers[j,1:nodaysvector[j]]- evapUH[1:nodaysvector[j]]
        if (round(sum(Layers[j,1:nodaysvector[j]])-sum(newLayer)- redea,8)!=0.0)
        {
           avvik <-round(sum(Layers[j,1:nodaysvector[j]]) -sum(newLayer)- redea,8) 
           print(paste ("Hei, feil i fordampning", avvik))
           browser()
        }  
        redea <-0.0
      }
      if (differ <= 0.0)# corresponds to that the Layer looses all water and redea is reduced, layer content < ea
      {
        newLayer[1:nodaysvector[j]] <-0.0
        redea <- redea - aktMag
        if(j==NoL) 
          {
            redea <-0   # 
            #ea <-  aktMag # cannot evaporate more than is present in the final Layer
          }
      }
     Layers[j,1:nodaysvector[j]] <- newLayer[1:nodaysvector[j]]                   # updating the actual layer
    }
    else# sumLayers ==0
    {
      ea <-0.0
    }
      
    }  
  }
   
  ea <- sum(LayersLast)-sum(Layers)
   
  if (ea > 0.0)
  {
     if (round(sum(LayersLast)-(ea+sum(Layers)),8) !=0.0)
     {
      print("Layers ut not OK") 
      browser()
     }
  }
  
  utLayerevap <-NULL
  utLayerevap$Layers <- Layers
  utLayerevap$ea <- ea
  utLayerevap
}
