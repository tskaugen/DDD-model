Ground_prec_CC <-function(SWE,Ta,Rp,Timeresinsec,snittT,PS)
{
#CC er kuldeinnhold som funksjon av SWe og sn�pakke temperatur
#Tidsoppl�ningsbestemte parametere: ingen
#Ground Heat
# PS sendens over i [mm]
# Rp Precipitation [mm]
# Ta air temperature

 GH <-173/86400 #kj/secund
 GH <- GH*Timeresinsec # desired resolution
#precipitation heat
rhow <- 1000 #kg/m3
CW <-4.19 #kJ/kg K varmekapasitet vann se p.199 Dingmann
if(Rp > 0.0)
{
 PH <-(rhow*CW*Rp*Ta)
}
else
{
 PH <-0.0
}

#Energi lagret i snowpack
cc <- 2.102 #kJ/kgK  varmekapasitet is, se Dingman p. 189
#Ts er gjennomsnittlig sn�temperatur
CC <-rhow*cc*(SWE+PS/1000)*(snittT) #kan kun bli negativ eller null SWE er i [m] uttrykket er i meter


resultGround_prec_coldcont <-NULL
resultGround_prec_coldcont$GH <-GH
resultGround_prec_coldcont$PH <-PH
resultGround_prec_coldcont$CC<-CC
resultGround_prec_coldcont
}