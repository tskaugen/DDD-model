ConvUTM_latlong<-function(x,y)
{
#konverterer til lat long i radianer###############
#print(paste("x=",x,"y=",y))
#x <-190583			# H�lervann
#y <-6742214			#H�lervann
#start p� mekkfor � finne latitude
utmx <-x-500000
utmy <- y
k0 <- 0.9996
long0 <-15.0*pi/180 # 15 grader er Central meridian i sone 33  15*pi/180  gir radianer
M <- utmy/k0 #Meridional arc
a <- 6378137 #Eq, radius meters
b <-6356752.3141 #Pola radius meters
e <-(1-(b^2/a^2))^0.5#e <-0.08
e2 <-(e*a/b)^2#e2 <-0.007
mu <- M/(a*(1-(e^2/4)-3*(e^4/64)-5*(e^6/256)))
e1 <-(1-(1-e^2)^0.5)/(1+(1-e^2)^0.5)
j1<-3*(e1/2)-27*(e1^3/32)
j2 <-21*(e1^2/16)-55*(e1^4/32)
j3 <- 151*(e1^3/96)
j4 <- (1097*e1^4)/512
fp <-mu + j1*sin(2*mu)+j2*sin(4*mu)+j3*sin(6*mu)+j4*sin(8*mu)
C1 <-e2*cos(fp)^2
T1 <-tan(fp)^2
R1 <- a*(1-e^2)/(1-e^2*sin(fp)^2)^1.5
N1 <- a/(1-e^2*sin(fp)^2)^0.5
D <-utmx/(N1*k0)
Q1<- N1*tan(fp)/R1
Q2<- (D^2/2)
Q3<-(5+3*T1+10*C1-4*C1^2-9*e2)*D^4/24
Q4<- (61+90*T1+298*C1+45*T1^2-3*C1^2-252*e2)*D^6/720
Q5<-D
Q6<-(1+2*T1+C1)*D^3/6
Q7<-(5-2*C1+28*T1-3*C1^2+8*e2+24*T1^2)*D^5/120

phi <- fp-Q1*(Q2-Q3+Q4)#latitude radianer
thi <- long0 +(Q5-Q6+Q7)/cos(fp)#longitude  radianer
phi_lat <- phi*180/pi#latitude grader
thi_long <- thi*180/pi#longitude grader
#print(phi_lat)
#print(thi_long)
#slutt p� mekk for � finne latitude
resultConvUTM_latlong<- NULL
resultConvUTM_latlong$phi<- phi #latitude
resultConvUTM_latlong$thi<- thi #longitude
resultConvUTM_latlong
}