
#    Function GrW_point
#
#------------------------------------------------------------------------
#     Description: Estimates moisture (groundwater) at a point in the hillslope
#
#     Author:  Thomas Skaugen
#     Revised: 04.01.2018
#--------------------------------------------------------------------------

GrW_Point <- function(nodaysvector, k, NoL, Areas, Layers, totarea, distvec, delta_d)
{

# actual mm at the site is Layers* totarea/areas, see Eq 27 in Kr�b�l, 2016
  Layers_mm <- Layers
  for (i in 1: NoL){
    for (j in 1: nodaysvector[i])Layers_mm[i,j] <- (Layers[i,j]/Areas[i,j])*totarea
  }
  
ant <- length(distvec)             # number of groundwater bore hole locations
grw <- vector("numeric", ant)      # vector for storing groundwater values for the current Layer 

#if(k==1435)browser()
for (i in 1:ant)                   
{
  tall <- as.numeric(distvec[i])
  grw[i] <- 0.0
  for (j in 1: NoL)
  {
   grw[i] <-grw[i]+ Layers_mm[j,((tall%/% delta_d[j])+1)]
  }
}
#browser()

resultgrw <- NULL
resultgrw <- grw
resultgrw
}
